# CareNet – Agentic Healthcare Ecosystem (hackathon scaffold)

Patient → Patient Agent → Risk Agent → **Shared Care Plan (Postgres/SQLite + Chroma)** → Emergency / Clinician / Caregiver / Wellness agents.
Orchestrated with **LangGraph**. Works with GPT-4o *or* local Llama (Ollama). Runs with no LLM at all (rule-based fallbacks).

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # add OPENAI_API_KEY or LLM_BASE_URL (Ollama); then: export $(grep -v '^#' .env | xargs)
python -m carenet.train_risk   # trains models/risk.joblib
python -m carenet.demo         # CLI demo of the winning flow
uvicorn carenet.app:api --reload   # UI + map at http://localhost:8000
python -m carenet.run_eval     # measure agents (watch UNDER-triage = 0)
# optional Postgres: docker compose up -d ; set DATABASE_URL in .env
```
First Chroma use downloads a small embedding model (needs internet once). Hospital search needs internet.
Edit the User-Agent email in `carenet/hospitals.py` (Nominatim policy, max 1 req/s).

## How the agents "learn" (there is no single training step)
| Layer | What | Where |
|---|---|---|
| Trained ML | Risk classifier (HistGradientBoosting). Final risk = **max(rules, model)**, so ML can only escalate | `train_risk.py` |
| Evaluation | Scenario tests; metric = under-triage | `eval/scenarios.jsonl`, `run_eval.py` |
| Memory | Patient history in Chroma, recalled each turn | `memory.py` |
| Feedback loop | Clinician corrections -> Chroma -> few-shot context for the clinician agent | `feedback.py`, `POST /feedback` |
| Prompt tuning | Edit prompts in `agents.py`, re-run eval, keep what lowers under-triage | — |
| Fine-tuning (optional) | Export corrected cases from `events` + corrections to JSONL, fine-tune Llama (LoRA) | later |

## IMPORTANT limitations
- Rules and thresholds are illustrative, **not clinically validated**. The ML model is bootstrapped on synthetic data
  labelled by those rules, so it mostly mimics them. Replace `make_data()` with clinician-labelled/de-identified real data.
- Not a medical device. Present it as decision support; a clinician should review the thresholds before any real use.
- Notifications are stored in DB only; wire `db.notify` to Twilio/WhatsApp/email for real delivery.
- Hindi/English keywords included; add more languages in `risk.KEYWORDS` (LLM extraction covers more when configured).
