"""Evaluate the agent network:  python -m carenet.run_eval
Key metric = UNDER-TRIAGE (predicting lower risk than truth). Improve prompts/rules/model until it is 0."""
import json, os
from . import db
from .graph import build
from .risk import LEVELS

db.init_db(); pid = db.seed_demo(); app = build()
rows = [json.loads(l) for l in open(os.path.join(os.path.dirname(__file__), "..", "eval", "scenarios.jsonl")) if l.strip()]
ok = under = over = spec_ok = spec_n = 0
for r in rows:
    out = app.invoke({"patient_id": pid, "text": r["text"], "vitals": r.get("vitals", {}), "trace": []})
    got, exp = LEVELS.index(out["risk_level"]), LEVELS.index(r["expected"])
    ok += got == exp; under += got < exp; over += got > exp
    if r.get("specialist"):
        spec_n += 1; spec_ok += r["specialist"].lower() in (out.get("emergency") or {}).get("specialist", "").lower()
    flag = "OK " if got == exp else ("UNDER!" if got < exp else "over")
    print(f"[{flag}] expected={r['expected']:<9} got={out['risk_level']:<9} | {r['text'][:60]}")
n = len(rows)
print(f"\nAccuracy {ok}/{n} | UNDER-triage {under} | over-triage {over} | specialist match {spec_ok}/{spec_n}")
