"""Clinician feedback loop = how the agents 'learn' without fine-tuning.
Corrections are embedded in ChromaDB and injected as few-shot context into the clinician agent."""
from . import memory


def add_correction(case_text, agent_said, clinician_says, note=""):
    memory.add("clinician_corrections",
               f"CASE: {case_text} | AGENT: {agent_said} | CORRECT: {clinician_says} | NOTE: {note}", {"kind": "correction"})
