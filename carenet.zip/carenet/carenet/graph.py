"""LangGraph orchestration:  patient -> risk -> shared care plan -> (route by risk) -> agents."""
import operator
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, END
from . import agents


class State(TypedDict, total=False):
    patient_id: int; text: str; vitals: dict; symptoms: list; patient: dict; memory_context: list
    risk_level: str; risk_reasons: list; risk_detail: dict; patient_reply: str
    emergency: dict; clinician_summary: str; caregiver_message: str; wellness_tips: list
    trace: Annotated[list, operator.add]


def route(state):
    return {"HIGH": "emergency", "CRITICAL": "emergency", "MODERATE": "clinician"}.get(state["risk_level"], "wellness")


def build():
    g = StateGraph(State)
    for name, fn in [("patient", agents.patient_agent), ("risk", agents.risk_agent), ("plan", agents.update_plan),
                     ("emergency", agents.emergency_agent), ("clinician", agents.clinician_agent),
                     ("caregiver", agents.caregiver_agent), ("wellness", agents.wellness_agent)]:
        g.add_node(name, fn)
    g.set_entry_point("patient")
    g.add_edge("patient", "risk"); g.add_edge("risk", "plan")
    g.add_conditional_edges("plan", route, {"emergency": "emergency", "clinician": "clinician", "wellness": "wellness"})
    g.add_edge("emergency", "clinician"); g.add_edge("clinician", "caregiver")
    g.add_edge("caregiver", "wellness"); g.add_edge("wellness", END)
    return g.compile()
