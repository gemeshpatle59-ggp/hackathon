"""TRAIN the risk model:  python -m carenet.train_risk
Uses synthetic data labelled by the safety rules + label noise as a bootstrap so the pipeline works end-to-end.
For real value: replace make_data() with clinician-labelled / de-identified real data and re-run."""
import os, random, numpy as np, joblib
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from .risk import SYMPTOMS, rule_level, features, LEVELS

CONDS = ["hypertension", "type 2 diabetes", "heart disease", "copd", "arthritis", "ckd"]


def make_data(n=30000, seed=0):
    rng = random.Random(seed); X, y = [], []
    for _ in range(n):
        age = rng.randint(60, 95)
        conds = rng.sample(CONDS, rng.randint(0, 4))
        v = {"sys": int(rng.gauss(130, 25)), "dia": int(rng.gauss(80, 14)), "glucose": int(abs(rng.gauss(130, 70))) + 40,
             "spo2": min(100, int(rng.gauss(95, 4))), "hr": int(rng.gauss(80, 18)), "temp": round(rng.gauss(36.9, 0.8), 1)}
        sy = [s for s in SYMPTOMS if rng.random() < (0.04 if s != "headache" else 0.08)]
        lvl, _ = rule_level(age, v, sy, conds)
        if rng.random() < 0.05:  # label noise stands in for clinician disagreement
            lvl = min(3, max(0, lvl + rng.choice([-1, 1])))
        X.append(features(age, v, sy, conds)); y.append(lvl)
    return np.array(X), np.array(y)


if __name__ == "__main__":
    X, y = make_data()
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=1, stratify=y)
    clf = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1, random_state=1).fit(Xtr, ytr)
    pred = clf.predict(Xte)
    print(classification_report(yte, pred, target_names=LEVELS))
    cm = confusion_matrix(yte, pred)
    print(cm)
    under = int(sum(cm[i][j] for i in range(4) for j in range(i)))
    print("Under-triage cases (predicted lower than true):", under, "of", len(yte))
    out = os.path.join(os.path.dirname(__file__), "..", "models", "risk.joblib")
    joblib.dump(clf, out); print("saved", out)
