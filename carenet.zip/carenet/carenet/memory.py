"""Long-term memory (ChromaDB). Falls back to a tiny in-RAM store if chromadb is unavailable."""
import os, uuid
_client = None
_fallback = {}


def _col(name):
    global _client
    try:
        import chromadb
        if _client is None:
            _client = chromadb.PersistentClient(path=os.getenv("CHROMA_PATH", "chroma_data"))
        return _client.get_or_create_collection(name)
    except Exception:
        return None


def add(collection, text, meta=None):
    c = _col(collection)
    if c is not None:
        c.add(ids=[str(uuid.uuid4())], documents=[text], metadatas=[meta or {"_": "_"}])
    else:
        _fallback.setdefault(collection, []).append(text)


def recall(collection, query, k=4, where=None):
    c = _col(collection)
    if c is not None:
        try:
            if c.count() == 0:
                return []
            r = c.query(query_texts=[query], n_results=min(k, c.count()), where=where)
            return r["documents"][0]
        except Exception:
            return []
    words = set(query.lower().split())
    docs = _fallback.get(collection, [])
    return sorted(docs, key=lambda d: -len(words & set(d.lower().split())))[:k]
