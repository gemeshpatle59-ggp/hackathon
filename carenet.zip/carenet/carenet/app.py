"""API + UI:  uvicorn carenet.app:api --reload   then open http://localhost:8000"""
import os, tempfile
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel
from . import db, feedback
from .graph import build

db.init_db(); db.seed_demo()
api = FastAPI(title="CareNet"); graph = build()


class Report(BaseModel):
    patient_id: int = 1; text: str; vitals: dict = {}


class Correction(BaseModel):
    case_text: str; agent_said: str; clinician_says: str; note: str = ""


@api.post("/report")
def report(r: Report):
    return graph.invoke({"patient_id": r.patient_id, "text": r.text, "vitals": r.vitals, "trace": []})


@api.get("/plan/{pid}")
def plan(pid: int):
    return {"plan": db.get_plan(pid), "events": db.recent_events(pid, 20)}


@api.post("/feedback")
def fb(c: Correction):
    feedback.add_correction(c.case_text, c.agent_said, c.clinician_says, c.note); return {"ok": True}


@api.post("/transcribe")
async def transcribe(file: UploadFile = File(...)):
    from faster_whisper import WhisperModel  # speech-to-text (auto-detects language)
    global _w
    if "_w" not in globals(): _w = WhisperModel(os.getenv("WHISPER_SIZE", "small"), compute_type="int8")
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(await file.read())
    segs, info = _w.transcribe(f.name)
    return {"text": " ".join(s.text for s in segs), "language": info.language}


@api.get("/")
def index():
    return FileResponse(os.path.join(os.path.dirname(__file__), "..", "static", "index.html"))
