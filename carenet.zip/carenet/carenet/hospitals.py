"""Hospital discovery via OpenStreetMap Nominatim + specialist recommendation."""
import math, time, requests

UA = {"User-Agent": "carenet-hackathon/0.1 (contact: you@example.com)"}  # Nominatim requires a UA; set your email
SPECIALIST = [  # (symptom, specialist, name keywords that hint the hospital has the service)
    ("one_sided_weakness", "Neurologist / Stroke unit", ["neuro", "brain", "stroke", "multispeciality", "multi speciality", "super"]),
    ("chest_pain", "Cardiologist / Cardiac emergency", ["heart", "cardi", "multispeciality", "multi speciality", "super"]),
    ("breathless", "Pulmonologist / Emergency medicine", ["chest", "lung", "pulmo", "multispeciality", "super"]),
    ("confusion", "Neurologist / Geriatrician", ["neuro", "geriatr", "multispeciality", "super"]),
    ("fall", "Orthopedic / Emergency medicine", ["ortho", "trauma", "bone", "multispeciality"]),
]
_last = 0.0


def recommend_specialist(symptoms, vitals):
    for s, spec, kw in SPECIALIST:
        if s in symptoms:
            return spec, kw
    g = vitals.get("glucose")
    if g is not None and (g < 70 or g > 300):
        return "Endocrinologist / Emergency medicine", ["diabet", "endocrin", "multispeciality"]
    return "Emergency medicine / General physician", ["multispeciality", "general", "emergency"]


def _km(a, b, c, d):
    p = math.pi / 180
    h = 0.5 - math.cos((c - a) * p) / 2 + math.cos(a * p) * math.cos(c * p) * (1 - math.cos((d - b) * p)) / 2
    return 12742 * math.asin(math.sqrt(h))


def nearest_hospitals(lat, lon, hints=(), n=5):
    global _last
    for box in (0.1, 0.25):  # ~11 km then ~28 km
        wait = 1.1 - (time.time() - _last)
        if wait > 0: time.sleep(wait)  # Nominatim: max 1 req/sec
        _last = time.time()
        try:
            r = requests.get("https://nominatim.openstreetmap.org/search", headers=UA, timeout=10, params={
                "q": "hospital", "format": "jsonv2", "limit": 30, "bounded": 1,
                "viewbox": f"{lon-box},{lat+box},{lon+box},{lat-box}"})
            rows = r.json()
        except Exception as e:
            return [], f"Hospital lookup failed: {e}"
        if rows: break
    out = []
    for x in rows:
        name = x.get("name") or x.get("display_name", "").split(",")[0]
        d = _km(lat, lon, float(x["lat"]), float(x["lon"]))
        hint = any(h in name.lower() for h in hints)
        out.append({"name": name, "lat": float(x["lat"]), "lon": float(x["lon"]),
                    "km": round(d, 1), "specialty_hint": hint})
    out.sort(key=lambda h: (h["km"] - (2.0 if h["specialty_hint"] else 0)))  # mild bonus for likely fit
    return out[:n], ("" if out else "No hospitals found in OSM near this location")
