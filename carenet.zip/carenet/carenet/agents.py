"""All agents. Each takes the shared graph state and returns updates. All have an LLM-free fallback."""
import json, os, re
from . import db, llm, memory, risk, hospitals

LANG = {"en": "English", "hi": "Hindi", "mr": "Marathi", "ta": "Tamil", "bn": "Bengali", "te": "Telugu"}


def _regex_vitals(text):
    v = {}
    if (m := re.search(r"(\d{2,3})\s*/\s*(\d{2,3})", text)): v["sys"], v["dia"] = int(m[1]), int(m[2])
    if (m := re.search(r"(?:sugar|glucose)\D{0,12}(\d{2,3})", text, re.I)): v["glucose"] = int(m[1])
    if (m := re.search(r"(?:spo2|oxygen|saturation)\D{0,12}(\d{2,3})", text, re.I)): v["spo2"] = int(m[1])
    if (m := re.search(r"(?:temp(?:erature)?)\D{0,12}(\d{2,3}(?:\.\d)?)", text, re.I)): v["temp"] = float(m[1])
    return v


# 1 ---------------------------------------------------------------- Patient Agent
def patient_agent(state):
    pid, text = state["patient_id"], state.get("text", "")
    pat = db.get_patient(pid)
    mem = memory.recall(f"patient_{pid}", text, k=4)
    symptoms, regex_v = risk.keyword_symptoms(text), _regex_vitals(text)
    out = llm.chat(
        "You are a patient-support agent for an elderly patient. Extract facts from their message (any language). "
        'Return JSON: {"symptoms": [subset of ' + json.dumps(risk.SYMPTOMS) + '], "vitals": {"sys":int,"dia":int,"glucose":int,"spo2":int,"hr":int,"temp":float}} '
        "using only values stated. Do not guess.", text, json_mode=True)
    if out:
        try:
            j = json.loads(out)
            symptoms = sorted(set(symptoms) | {s for s in j.get("symptoms", []) if s in risk.SYMPTOMS})
            regex_v.update({k: v for k, v in (j.get("vitals") or {}).items() if v is not None})
        except Exception:
            pass
    vitals = {**regex_v, **{k: v for k, v in (state.get("vitals") or {}).items() if v is not None}}
    db.add_event(pid, "patient_report", {"text": text, "symptoms": symptoms, "vitals": vitals})
    memory.add(f"patient_{pid}", f"Patient said: {text} | symptoms={symptoms} vitals={vitals}", {"kind": "report"})
    return {"patient": pat, "symptoms": symptoms, "vitals": vitals, "memory_context": mem,
            "trace": ["patient_agent: recorded event, extracted symptoms/vitals, recalled memory"]}


# 2 ---------------------------------------------------------------- Risk Scoring Agent
def risk_agent(state):
    a = risk.assess(state["patient"], state["vitals"], state["symptoms"])
    return {"risk_level": a["level"], "risk_reasons": a["reasons"], "risk_detail": a,
            "trace": [f"risk_agent: {a['level']} (rules={a['rule_level']}, ml={a['ml_level']})"]}


# 3 ---------------------------------------------------------------- Shared Care Plan update
def update_plan(state):
    pid = state["patient_id"]
    plan = db.get_plan(pid)
    plan["risk_level"] = state["risk_level"]
    plan["flags"] = state["risk_reasons"]
    plan.setdefault("recent", []).append({"symptoms": state["symptoms"], "vitals": state["vitals"], "risk": state["risk_level"]})
    plan["recent"] = plan["recent"][-20:]
    db.save_plan(pid, plan)
    db.add_event(pid, "risk_assessment", {"reasons": state["risk_reasons"]}, state["risk_level"])
    reply = None
    p = state["patient"]
    lang = LANG.get(p.get("language", "en"), "English")
    reply = llm.chat(f"You are a warm, calm assistant for an elderly patient. Reply in {lang}, 2-3 short sentences, no jargon. "
                     "If risk is HIGH/CRITICAL say help is being arranged and to call the emergency number. Never diagnose.",
                     f"Patient said: {state['text']}\nRisk: {state['risk_level']}")
    if not reply:
        reply = ("Thank you for telling me. I have noted this and informed your family and doctor." if state["risk_level"] in ("LOW", "MODERATE")
                 else f"This looks serious. Please call {os.getenv('EMERGENCY_NUMBER','112')} now. I am alerting your family and finding the nearest hospital.")
    return {"patient_reply": reply, "trace": ["care_plan: shared state updated"]}


# 4 ---------------------------------------------------------------- Emergency Agent
def emergency_agent(state):
    p = state["patient"]
    spec, hints = hospitals.recommend_specialist(state["symptoms"], state["vitals"])
    hosp, note = ([], "No patient location on file")
    if p.get("lat") is not None:
        hosp, note = hospitals.nearest_hospitals(p["lat"], p["lon"], hints)
    em = {"specialist": spec, "hospitals": hosp, "note": note, "call": os.getenv("EMERGENCY_NUMBER", "112")}
    db.add_event(p["id"], "emergency_navigation", em, state["risk_level"])
    return {"emergency": em, "trace": [f"emergency_agent: specialist={spec}, {len(hosp)} hospitals found"]}


# 5 ---------------------------------------------------------------- Clinician Agent
def clinician_agent(state):
    p = state["patient"]
    fb = memory.recall("clinician_corrections", f"{state['symptoms']} {state['vitals']}", k=3)
    ctx = dict(patient={k: p[k] for k in ("name", "age", "conditions", "medicines")}, symptoms=state["symptoms"], vitals=state["vitals"],
               risk=state["risk_level"], reasons=state["risk_reasons"], history=db.recent_events(p["id"], 6),
               emergency=state.get("emergency"))
    s = llm.chat("You are a clinical-summary agent. Write a concise SBAR (Situation, Background, Assessment, Recommendation) for the treating doctor. "
                 "Only use supplied data; flag uncertainty. Learn from these past clinician corrections if relevant: " + json.dumps(fb),
                 json.dumps(ctx, default=str))
    if not s:
        s = (f"SBAR\nS: {p['name']}, {p['age']}y reports {', '.join(state['symptoms']) or 'no symptoms'}; vitals {state['vitals']}.\n"
             f"B: {', '.join(p['conditions'])}; meds: {', '.join(p['medicines'])}.\nA: Risk {state['risk_level']} - {'; '.join(state['risk_reasons'])}.\n"
             f"R: {'Urgent evaluation - ' + state['emergency']['specialist'] if state.get('emergency') else 'Review at next contact / monitor.'}")
    db.notify(p["id"], "clinician", s)
    return {"clinician_summary": s, "trace": ["clinician_agent: SBAR summary prepared + sent"]}


# 6 ---------------------------------------------------------------- Caregiver Agent
def caregiver_agent(state):
    p = state["patient"]; em = state.get("emergency")
    msg = llm.chat("Write a short, clear, non-alarming-but-honest SMS-style update (max 60 words) for a family caregiver. No medical jargon.",
                   json.dumps({"patient": p["name"], "risk": state["risk_level"], "symptoms": state["symptoms"], "vitals": state["vitals"],
                               "hospital": (em["hospitals"][0]["name"] if em and em["hospitals"] else None)}))
    if not msg:
        msg = f"Update on {p['name']}: reported {', '.join(state['symptoms']) or 'a routine check-in'}. Risk: {state['risk_level']}."
        if em: msg += f" Suggested: {em['specialist']}" + (f" at {em['hospitals'][0]['name']} ({em['hospitals'][0]['km']} km)." if em['hospitals'] else ".")
    db.notify(p["id"], "caregiver", msg)
    return {"caregiver_message": msg, "trace": ["caregiver_agent: family notified"]}


# 7 ---------------------------------------------------------------- Wellness Agent
def wellness_agent(state):
    lvl, conds = state["risk_level"], " ".join(state["patient"]["conditions"]).lower()
    if lvl in ("HIGH", "CRITICAL"):
        tips = ["Rest, stay seated or lying down; no walking or exertion until assessed.", "Keep medicines list ready for the doctor."]
    else:
        tips = ["10-15 minute gentle walk after meals if you feel well.", "Drink water regularly through the day (unless your doctor restricts fluids).",
                "Call a friend or family member today."]
        if "diab" in conds: tips.append("Check sugar as scheduled; keep a light snack handy.")
        if "hypert" in conds: tips.append("Keep salt low and take BP medicine at the usual time.")
    return {"wellness_tips": tips, "trace": ["wellness_agent: routine updated"]}
