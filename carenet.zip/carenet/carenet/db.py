"""Shared Care Plan database. Every agent reads/updates the same state here."""
import os, datetime as dt
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON, Text
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()
engine = create_engine(os.getenv("DATABASE_URL", "sqlite:///carenet.db"))
SessionLocal = sessionmaker(engine, expire_on_commit=False)


class Patient(Base):
    __tablename__ = "patients"
    id = Column(Integer, primary_key=True)
    name = Column(String); age = Column(Integer); language = Column(String, default="en")
    conditions = Column(JSON, default=list); medicines = Column(JSON, default=list)
    caregiver = Column(String); lat = Column(Float); lon = Column(Float)


class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True); patient_id = Column(Integer, index=True)
    ts = Column(DateTime, default=dt.datetime.utcnow)
    kind = Column(String); payload = Column(JSON); risk_level = Column(String)


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True); patient_id = Column(Integer, index=True)
    ts = Column(DateTime, default=dt.datetime.utcnow)
    audience = Column(String); message = Column(Text)


class CarePlan(Base):
    __tablename__ = "care_plans"
    patient_id = Column(Integer, primary_key=True)
    plan = Column(JSON, default=dict); updated_at = Column(DateTime, default=dt.datetime.utcnow)


def init_db():
    Base.metadata.create_all(engine)


def _p(p):
    return {c.name: getattr(p, c.name) for c in Patient.__table__.columns}


def seed_demo():
    """Demo patient (fictional). Location = central Mumbai; change for your demo city."""
    init_db()
    with SessionLocal() as s:
        p = s.get(Patient, 1)
        if not p:
            p = Patient(id=1, name="Asha Rao", age=72, language="hi",
                        conditions=["hypertension", "type 2 diabetes"],
                        medicines=["Amlodipine 5mg morning", "Metformin 500mg twice daily"],
                        caregiver="Son: Rahul (+91-0000000000)", lat=19.0760, lon=72.8777)
            s.add(p); s.commit()
    return 1


def get_patient(pid):
    with SessionLocal() as s:
        p = s.get(Patient, pid)
        return _p(p) if p else None


def add_event(pid, kind, payload, risk=None):
    with SessionLocal() as s:
        s.add(Event(patient_id=pid, kind=kind, payload=payload, risk_level=risk)); s.commit()


def recent_events(pid, n=10):
    with SessionLocal() as s:
        rows = s.query(Event).filter_by(patient_id=pid).order_by(Event.id.desc()).limit(n).all()
        return [{"ts": r.ts.isoformat(), "kind": r.kind, "payload": r.payload, "risk": r.risk_level} for r in rows]


def get_plan(pid):
    with SessionLocal() as s:
        c = s.get(CarePlan, pid)
        return dict(c.plan) if c else {"risk_level": "LOW", "flags": [], "recent": []}


def save_plan(pid, plan):
    with SessionLocal() as s:
        c = s.get(CarePlan, pid)
        if c:
            c.plan = plan; c.updated_at = dt.datetime.utcnow()
        else:
            s.add(CarePlan(patient_id=pid, plan=plan))
        s.commit()


def notify(pid, audience, message):
    with SessionLocal() as s:
        s.add(Notification(patient_id=pid, audience=audience, message=message)); s.commit()
