"""Risk scoring = deterministic safety rules (floor) + trained ML model. Final level = max of both.
The rules are an illustrative demo, NOT clinically validated. Have a clinician review before real use."""
import os
LEVELS = ["LOW", "MODERATE", "HIGH", "CRITICAL"]
SYMPTOMS = ["chest_pain", "breathless", "confusion", "fall", "one_sided_weakness",
            "fever", "dizziness", "headache"]
NORMAL = {"sys": 120, "dia": 80, "glucose": 110, "spo2": 97, "hr": 75, "temp": 36.8}
FEATURES = ["age", "sys", "dia", "glucose", "spo2", "hr", "temp", "n_conditions",
            "has_cardiac_risk"] + SYMPTOMS

KEYWORDS = {  # English + Hindi (Devanagari & romanised). Extend for Marathi/Tamil/etc.
    "chest_pain": ["chest pain", "chest tight", "सीने में दर्द", "seene mein dard", "chhati"],
    "breathless": ["breathless", "short of breath", "can't breathe", "cannot breathe", "सांस", "saans"],
    "confusion": ["confused", "disoriented", "not making sense", "भ्रम", "behosh"],
    "fall": ["fell", "fallen", "fall down", "गिर", "gir gaya", "gir gayi"],
    "one_sided_weakness": ["one side", "slurred", "face droop", "drooping", "arm weak", "लकवा", "lakwa"],
    "fever": ["fever", "बुखार", "bukhar"],
    "dizziness": ["dizzy", "giddy", "चक्कर", "chakkar"],
    "headache": ["headache", "सिरदर्द", "sir dard", "sar dard"],
}


def keyword_symptoms(text):
    t = (text or "").lower()
    return [s for s, kws in KEYWORDS.items() if any(k in t for k in kws)]


def rule_level(age, v, symptoms, conditions):
    """Returns (level_index, reasons)."""
    S = set(symptoms); lvl = 0; why = []

    def bump(l, r):
        nonlocal lvl
        lvl = max(lvl, l); why.append(r)
    g = lambda k: v.get(k)
    cardiac = any(c in " ".join(conditions).lower() for c in ["hypertension", "cardiac", "heart", "diabet"])
    if g("spo2") is not None:
        if g("spo2") < 90: bump(3, f"SpO2 {g('spo2')}% critically low")
        elif g("spo2") < 93: bump(2, f"SpO2 {g('spo2')}% low")
    if g("sys") is not None:
        crisis = g("sys") >= 180 or (g("dia") or 0) >= 120
        if crisis and S & {"headache", "confusion", "chest_pain", "one_sided_weakness", "breathless"}:
            bump(3, f"BP {g('sys')}/{g('dia')} with neurological/cardiac symptoms")
        elif crisis: bump(2, f"BP {g('sys')}/{g('dia')} hypertensive crisis range")
        elif g("sys") >= 160 or (g("dia") or 0) >= 100: bump(1, f"BP {g('sys')}/{g('dia')} elevated")
        elif g("sys") < 90: bump(2, f"BP {g('sys')}/{g('dia')} low")
    if g("glucose") is not None:
        if g("glucose") < 54 or g("glucose") > 400: bump(3, f"Glucose {g('glucose')} mg/dL dangerous")
        elif g("glucose") < 70 or g("glucose") > 300: bump(2, f"Glucose {g('glucose')} mg/dL abnormal")
        elif g("glucose") >= 200: bump(1, f"Glucose {g('glucose')} mg/dL high")
    if g("hr") is not None:
        if g("hr") > 130 or g("hr") < 45: bump(2, f"Heart rate {g('hr')} abnormal")
        elif g("hr") > 110: bump(1, f"Heart rate {g('hr')} raised")
    if g("temp") is not None:
        if g("temp") >= 39: bump(2, f"Temp {g('temp')}C high fever")
        elif g("temp") >= 38: bump(1, f"Temp {g('temp')}C fever")
    if "one_sided_weakness" in S: bump(3, "Possible stroke signs (FAST) - time critical")
    if "chest_pain" in S: bump(3 if (age >= 50 or cardiac) else 2, "Chest pain with cardiac risk factors")
    if "breathless" in S: bump(2, "Breathlessness")
    if "confusion" in S: bump(2, "New confusion in older adult")
    if "fall" in S: bump(2 if age >= 65 and "dizziness" in S else 1, "Fall reported")
    if S & {"fever", "dizziness"}: bump(1, "Fever/dizziness reported")
    return lvl, why


def features(age, v, symptoms, conditions):
    row = {"age": age, **{k: (v.get(k) if v.get(k) is not None else NORMAL[k]) for k in NORMAL},
           "n_conditions": len(conditions),
           "has_cardiac_risk": int(any(c in " ".join(conditions).lower() for c in ["hypertension", "cardiac", "heart", "diabet"]))}
    for s in SYMPTOMS: row[s] = int(s in symptoms)
    return [row[f] for f in FEATURES]


_model = None
def _load():
    global _model
    if _model is None:
        p = os.path.join(os.path.dirname(__file__), "..", "models", "risk.joblib")
        if os.path.exists(p):
            import joblib; _model = joblib.load(p)
        else:
            _model = False
    return _model


def assess(patient, vitals, symptoms):
    age, conds = patient["age"], patient.get("conditions", [])
    r_idx, reasons = rule_level(age, vitals, symptoms, conds)
    m_idx = None
    m = _load()
    if m:
        m_idx = int(m.predict([features(age, vitals, symptoms, conds)])[0])
        if m_idx > r_idx:
            reasons.append(f"ML model escalated risk to {LEVELS[m_idx]}")
    final = max(r_idx, m_idx or 0)  # safety-first: never below the rule floor
    return {"level": LEVELS[final], "rule_level": LEVELS[r_idx],
            "ml_level": LEVELS[m_idx] if m_idx is not None else None,
            "reasons": reasons or ["No abnormal findings"]}
