"""One LLM entry point. Works with GPT-4o or any OpenAI-compatible server (Ollama/vLLM + Llama).
Returns None when no LLM is configured so every agent has a rule-based fallback (demo works offline)."""
import os
_client = None


def available():
    return bool(os.getenv("OPENAI_API_KEY") or os.getenv("LLM_BASE_URL"))


def chat(system, user, json_mode=False, temperature=0.2):
    global _client
    if not available():
        return None
    try:
        from openai import OpenAI
        if _client is None:
            _client = OpenAI(base_url=os.getenv("LLM_BASE_URL") or None,
                             api_key=os.getenv("OPENAI_API_KEY", "ollama"))
        kw = {"response_format": {"type": "json_object"}} if json_mode else {}
        r = _client.chat.completions.create(
            model=os.getenv("LLM_MODEL", "gpt-4o"), temperature=temperature,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}], **kw)
        return r.choices[0].message.content
    except Exception as e:
        print("[llm] error:", e)
        return None
