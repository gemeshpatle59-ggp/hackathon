"""python -m carenet.demo"""
import json
from . import db
from .graph import build

db.init_db(); pid = db.seed_demo(); app = build()
for text, vit in [("Good morning, I walked a bit and drank water. BP 128/82", {}),
                  ("Mujhe seene mein dard ho raha hai aur chakkar aa rahe hain. BP 186/108", {"spo2": 95})]:
    print("\n" + "=" * 70 + f"\nPATIENT: {text}")
    r = app.invoke({"patient_id": pid, "text": text, "vitals": vit, "trace": []})
    for t in r["trace"]: print("  ->", t)
    print("RISK:", r["risk_level"], r["risk_reasons"])
    print("REPLY:", r["patient_reply"])
    if r.get("emergency"): print("EMERGENCY:", json.dumps(r["emergency"], indent=2)[:900])
    if r.get("clinician_summary"): print("CLINICIAN:\n" + r["clinician_summary"])
    if r.get("caregiver_message"): print("CAREGIVER:", r["caregiver_message"])
    print("WELLNESS:", r["wellness_tips"])
